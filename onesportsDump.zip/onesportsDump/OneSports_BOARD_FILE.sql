-- MySQL dump 10.13  Distrib 8.0.18, for Win64 (x86_64)
--
-- Host: familytotodb.cdxbvybenrsk.ap-northeast-2.rds.amazonaws.com    Database: OneSports
-- ------------------------------------------------------
-- Server version	5.7.26-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ '';

--
-- Table structure for table `BOARD_FILE`
--

DROP TABLE IF EXISTS `BOARD_FILE`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `BOARD_FILE` (
  `BOARD_FILE_NO` int(11) NOT NULL AUTO_INCREMENT COMMENT '100001',
  `BOARD_NO` bigint(20) NOT NULL,
  `BOARD_FILE_PATH` varchar(200) NOT NULL,
  `BOARD_FILE_NAME` varchar(255) NOT NULL,
  `REG_CUST_NO` bigint(20) NOT NULL,
  `CHG_CUST_NO` bigint(20) DEFAULT NULL,
  `REG_DT` datetime NOT NULL,
  `CHG_DT` datetime DEFAULT NULL,
  `REG_IP` varchar(20) NOT NULL,
  `CHG_IP` varchar(20) DEFAULT NULL,
  `USE_YN` char(1) NOT NULL COMMENT 'Y,N,B',
  PRIMARY KEY (`BOARD_FILE_NO`),
  KEY `FK_BOARD_FILE_BOARD_NO_BOARD_BOARD_NO` (`BOARD_NO`),
  CONSTRAINT `FK_BOARD_FILE_BOARD_NO_BOARD_BOARD_NO` FOREIGN KEY (`BOARD_NO`) REFERENCES `BOARD` (`BOARD_NO`)
) ENGINE=InnoDB AUTO_INCREMENT=100049 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `BOARD_FILE`
--

LOCK TABLES `BOARD_FILE` WRITE;
/*!40000 ALTER TABLE `BOARD_FILE` DISABLE KEYS */;
INSERT INTO `BOARD_FILE` VALUES (100001,10000169,'/file/board/2019/09/03/1567479396309_64street.cfg','64street.cfg',0,NULL,'2019-09-03 11:57:22',NULL,'127.0.0.1',NULL,'Y'),(100002,10000170,'/file/board/2019/09/03/1567481120980_airattck.cfg','airattck.cfg',0,NULL,'2019-09-03 12:26:10',NULL,'127.0.0.1',NULL,'Y'),(100003,10000171,'/file/board/2019/09/03/1567481230762_altbeast.cfg','altbeast.cfg',0,NULL,'2019-09-03 12:28:41',NULL,'127.0.0.1',NULL,'Y'),(100004,10000178,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/03/1567493863971_정렬정리.txt','정렬정리.txt',0,NULL,'2019-09-03 15:57:48',NULL,'127.0.0.1',NULL,'Y'),(100005,10000180,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/03/1567494050463_LICENSE','LICENSE',0,NULL,'2019-09-03 16:02:20',NULL,'127.0.0.1',NULL,'Y'),(100006,10000194,'/file/board/2019/09/03/1567495940453_새 텍스트 문서.txt','새 텍스트 문서.txt',0,NULL,'2019-09-03 16:32:26',NULL,'127.0.0.1',NULL,'Y'),(100007,10000195,'/file/board/2019/09/03/1567495976126_0902 1.exe','0902 1.exe',0,NULL,'2019-09-03 16:33:25',NULL,'127.0.0.1',NULL,'Y'),(100008,10000196,'/file/board/2019/09/03/1567496075496_1.PNG','1.PNG',0,NULL,'2019-09-03 16:34:46',NULL,'127.0.0.1',NULL,'Y'),(100009,10000197,'/file/board/2019/09/03/1567496075496_1.PNG','1.PNG',0,NULL,'2019-09-03 16:35:03',NULL,'127.0.0.1',NULL,'Y'),(100010,10000198,'/file/board/2019/09/03/1567496265459_새 텍스트 문서.txt','새 텍스트 문서.txt',0,NULL,'2019-09-03 16:37:52',NULL,'127.0.0.1',NULL,'Y'),(100011,10000199,'/file/board/2019/09/03/1567496368894_0902 2.exe','0902 2.exe',0,NULL,'2019-09-03 16:41:31',NULL,'127.0.0.1',NULL,'Y'),(100012,10000200,'/file/board/2019/09/03/1567496368894_0902 2.exe','0902 2.exe',0,NULL,'2019-09-03 16:41:46',NULL,'127.0.0.1',NULL,'Y'),(100013,10000211,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/03/1567508363878_1527405700405.jpg','1527405700405.jpg',0,NULL,'2019-09-03 20:00:07',NULL,'127.0.0.1',NULL,'Y'),(100014,10000216,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/03/1567511988237_MAME.ini','MAME.ini',0,200000035,'2019-09-03 21:00:30','2019-09-03 21:40:30','127.0.0.1','127.0.0.1','N'),(100015,10000216,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/03/1567514534695_64street.ico','64street.ico',200000035,200000035,'2019-09-03 21:42:55','2019-09-03 21:45:18','127.0.0.1',NULL,'N'),(100016,10000216,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/03/1567514678528_8ball.ico','8ball.ico',200000035,NULL,'2019-09-03 21:45:18',NULL,'127.0.0.1',NULL,'Y'),(100017,10000261,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/06/1567773586651_19xxh.ico','19xxh.ico',0,NULL,'2019-09-06 21:40:37',NULL,'127.0.0.1',NULL,'Y'),(100018,10000262,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/06/1567773630001_zzyzzyx2.ico','zzyzzyx2.ico',100000044,100000044,'2019-09-06 21:41:10','2019-09-06 22:18:19','127.0.0.1','127.0.0.1','N'),(100019,10000263,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/06/1567775885914_19xxh.ico','19xxh.ico',100000044,100000044,'2019-09-06 22:18:46','2019-09-06 22:22:22','127.0.0.1','127.0.0.1','N'),(100020,10000263,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/06/1567776242488_19xxh.ico','19xxh.ico',100000044,100000044,'2019-09-06 22:24:44','2019-09-06 22:25:08','127.0.0.1','127.0.0.1','N'),(100021,10000263,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/06/1567776265288_arabiana.ico','arabiana.ico',100000044,NULL,'2019-09-06 22:25:08',NULL,'127.0.0.1',NULL,'Y'),(100022,10000264,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/09/1568007354440_IMG_20170905_164459457.jpg','IMG_20170905_164459457.jpg',0,NULL,'2019-09-09 14:36:49',NULL,'127.0.0.1',NULL,'Y'),(100023,10000265,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/09/1568007864094_IMG_20170905_164459457.jpg','IMG_20170905_164459457.jpg',0,NULL,'2019-09-09 14:45:05',NULL,'127.0.0.1',NULL,'Y'),(100024,10000266,'','',0,NULL,'2019-09-09 23:49:02',NULL,'127.0.0.1',NULL,'Y'),(100025,10000267,'','',0,NULL,'2019-09-09 23:52:46',NULL,'127.0.0.1',NULL,'Y'),(100026,10000268,'','',0,NULL,'2019-09-09 23:53:10',NULL,'127.0.0.1',NULL,'Y'),(100027,10000273,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/10/1568041999958_1490781296663.jpeg','1490781296663.jpeg',0,NULL,'2019-09-10 00:14:02',NULL,'127.0.0.1',NULL,'Y'),(100028,10000316,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/14/1568457930736_one-sports-private.ppk','one-sports-private.ppk',100000050,100000050,'2019-09-14 19:45:37','2019-09-14 19:54:24','162.158.6.131','162.158.6.131','N'),(100029,10000317,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/14/1568458104800_테스트.txt','테스트.txt',0,NULL,'2019-09-14 19:48:35',NULL,'162.158.7.60',NULL,'Y'),(100030,10000318,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/14/1568458196037_테스트.txt','테스트.txt',200000025,NULL,'2019-09-14 19:49:57',NULL,'162.158.7.60',NULL,'Y'),(100031,10000316,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/14/1568458501601_one-sports-private.ppk','one-sports-private.ppk',100000050,NULL,'2019-09-14 19:55:03',NULL,'162.158.6.131',NULL,'Y'),(100032,10000321,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/14/1568469851227_leage.jpg','leage.jpg',100000044,NULL,'2019-09-14 23:05:05',NULL,'127.0.0.1',NULL,'Y'),(100033,10000341,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/17/1568698955109_1.PNG','1.PNG',0,0,'2019-09-17 14:42:43','2019-09-17 14:44:07','127.0.0.1','127.0.0.1','N'),(100034,10000341,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/17/1568699044070_1.PNG','1.PNG',0,NULL,'2019-09-17 14:44:07',NULL,'127.0.0.1',NULL,'Y'),(100035,10000342,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/17/1568699454016_1.PNG','1.PNG',100000039,NULL,'2019-09-17 14:51:41',NULL,'127.0.0.1',NULL,'Y'),(100036,10000343,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/17/1568701513247_1.PNG','1.PNG',0,NULL,'2019-09-17 15:25:18',NULL,'127.0.0.1',NULL,'Y'),(100037,10000357,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/17/1568702981250_1.PNG','1.PNG',0,NULL,'2019-09-17 15:49:49',NULL,'162.158.6.143',NULL,'Y'),(100038,10000384,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/17/1568706889635_1.PNG','1.PNG',0,NULL,'2019-09-17 16:54:51',NULL,'127.0.0.1',NULL,'Y'),(100039,10000385,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/17/1568706898608_091.c','091.c',0,NULL,'2019-09-17 16:55:01',NULL,'127.0.0.1',NULL,'Y'),(100040,10000392,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/18/1568766172750_3번.PNG','3번.PNG',100000055,NULL,'2019-09-18 09:23:03',NULL,'162.158.7.66',NULL,'Y'),(100041,10000402,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/18/1568778516048_css2.ctl','css2.ctl',0,0,'2019-09-18 12:48:56','2019-09-18 12:50:43','162.158.7.120','162.158.7.120','N'),(100042,10000403,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/18/1568782824820_0206.pkt','0206.pkt',100000058,NULL,'2019-09-18 14:01:24',NULL,'162.158.6.113',NULL,'Y'),(100043,10000460,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/09/19/1568873280205_99b983892094b5c6d2fc3736e15da7d1.gif.mp4','99b983892094b5c6d2fc3736e15da7d1.gif.mp4',200000041,NULL,'2019-09-19 15:08:06',NULL,'162.158.6.89',NULL,'Y'),(100044,10000524,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/10/06/1570365881981_donpackr.ico','donpackr.ico',200000033,NULL,'2019-10-06 21:45:37',NULL,'127.0.0.1',NULL,'Y'),(100045,10000529,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/10/21/1571584920923_plare-logo.jpg','plare-logo.jpg',100000044,NULL,'2019-10-21 00:23:05',NULL,'127.0.0.1',NULL,'Y'),(100046,10000536,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/10/26/1572071479257_테스트.txt','테스트.txt',100000039,NULL,'2019-10-26 15:33:49',NULL,'172.68.211.221',NULL,'Y'),(100047,10000543,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/10/28/1572250152392_게1.jpg','게1.jpg',0,NULL,'2019-10-28 17:09:39',NULL,'162.158.7.54',NULL,'Y'),(100048,10000548,'https://onesports.s3.ap-northeast-2.amazonaws.com/file/board/2019/11/01/1572590804779_B반2조 메인.png','B반2조 메인.png',0,NULL,'2019-11-01 15:46:48',NULL,'162.158.6.143',NULL,'Y');
/*!40000 ALTER TABLE `BOARD_FILE` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-12-06 13:26:39
